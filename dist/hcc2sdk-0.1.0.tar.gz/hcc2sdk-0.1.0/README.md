README

hcc2sdk is the api package to build/deploy to interface with  HCC2 through modbus

to build a new version of this package, run:

./build.sh   <---- this will build the new package distribution files

pip install dist/hcc2sdk-0.1.0-py3-none-any.whl --force-reinstall      <------- This install the package for the current user.

